package com.example;

public interface FiguraInterface {
    float calcularSuperficie();
}
